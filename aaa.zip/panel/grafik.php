<?php
$_GET['route'] = 'grafik';
require __DIR__ . '/index.php';
?>
