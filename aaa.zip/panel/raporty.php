<?php
$_GET['route'] = 'raporty';
require __DIR__ . '/index.php';
?>
