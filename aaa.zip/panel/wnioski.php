<?php
$_GET['route'] = 'wnioski';
require __DIR__ . '/index.php';
?>
