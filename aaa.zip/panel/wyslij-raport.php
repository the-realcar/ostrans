<?php
$_GET['route'] = 'wyslij-raport';
require __DIR__ . '/index.php';
?>
