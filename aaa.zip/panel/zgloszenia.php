<?php
$_GET['route'] = 'zgloszenia';
require __DIR__ . '/index.php';
?>
