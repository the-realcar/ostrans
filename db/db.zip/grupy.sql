INSERT INTO grupy (grupa)
VALUES ('MINI'),
('MIDI'),
('MAXI'),
('MAXI+'),
('MEGA'),
('MEGA+'),
('1WW'),
('2WW'),
('1WN'),
('2WN'),
('A'),
('B'),
('C');