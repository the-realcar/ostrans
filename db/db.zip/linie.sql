INSERT INTO linie (nr_linii, typ, start_point, end_point) 
VALUES 
('107', 'bus', 'Salwator', 'Boernerowo'),
('116', 'bus', 'Osiedle Zgody', 'Blachownia');
