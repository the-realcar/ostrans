INSERT INTO naprawy ()
VALUES ();