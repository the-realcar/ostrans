INSERT INTO pracownicy (imie, nazwisko, login, haslo, stanowisko_id, uprawnienie_id, email, is_active)
VALUES 
('Dawid','Volve','the_realcar','dpass', 2, 3, 'driver@ostrans.pl', true),
('Hubert Jakub','Tryniecki','kustul','hpass', 14, 2, 'dispatcher@ostrans.pl', true),
('Admin','User','admin1','$2y$10$XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX', 18, 1, 'admin@ostrans.pl', true);
