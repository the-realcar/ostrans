INSERT INTO przeglady ()
VALUES ();