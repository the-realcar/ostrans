INSERT INTO przetargi ()
VALUES ();