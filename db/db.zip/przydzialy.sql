INSERT INTO przydzialy (id_pojazdu, id_pracownka, data_od, data_do)
VALUES ();