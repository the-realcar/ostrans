INSERT INTO rodzaje_przegladow (nazwa_rodzaju_przegladu)
VALUES ('O1'),
('OT'),
('OM'),
('OR'),
('OO'),
('OD'),
('OS'),
('OES');