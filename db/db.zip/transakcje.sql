INSERT INTO transakcje ()
VALUES ();