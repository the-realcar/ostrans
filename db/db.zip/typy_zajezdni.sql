INSERT INTO typy_zajezdni (nazwa_typu)
VALUES ('Autobusowa'),
('Trolejbusowa'),
('Tramwajowa'),
('Autobusowo-trolejbusowa'),
('Inna');