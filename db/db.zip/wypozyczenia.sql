INSERT INTO wypozyczenia ()
VALUES ();