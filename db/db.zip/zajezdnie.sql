INSERT INTO zajezdnie (nazwa_zajezdni, id_typu_zajezdni)
VALUES ('OKM', 4),
('OMC', 1),
('OKW', 3),
('OKA', 3),
('Zarząd', 5);